'use strict';

const STORAGE_KEY = 'dopamine-reset-data-v1';
const FA_DIGITS = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
const DAY_MS = 86400000;

const defaultData = {
  version: 1,
  createdAt: new Date().toISOString(),
  points: 0,
  goals: [],
  completions: {},
  urges: [],
  focusSessions: [],
  reflections: {},
  settings: {
    dayStartTime: '07:00',
    nightReminderTime: '22:00',
    gentleMode: true,
    showLevel: true,
    sound: false
  }
};

let data = loadData();
let activeView = 'today';
let activeGoalFilter = 'all';
let calendarCursor = new Date();
let selectedCalendarDate = dateKey(new Date());
let deferredInstallPrompt = null;
let focusState = { total: 25 * 60, remaining: 25 * 60, running: false, interval: null, startedAt: null };
let urgeState = { total: 10 * 60, remaining: 10 * 60, running: false, interval: null };
let toastTimer = null;

const el = (id) => document.getElementById(id);
const qsa = (selector, root = document) => [...root.querySelectorAll(selector)];

function clone(value) { return JSON.parse(JSON.stringify(value)); }
function uid() { return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`; }
function toFa(value) { return String(value).replace(/\d/g, d => FA_DIGITS[Number(d)]); }
function pad(value) { return String(value).padStart(2, '0'); }
function dateKey(date) { return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`; }
function parseDateKey(key) { const [y, m, d] = key.split('-').map(Number); return new Date(y, m - 1, d); }
function startOfDay(date) { return new Date(date.getFullYear(), date.getMonth(), date.getDate()); }
function daysBetween(a, b) { return Math.round((startOfDay(b) - startOfDay(a)) / DAY_MS); }
function clamp(num, min, max) { return Math.max(min, Math.min(max, num)); }
function percent(part, total) { return total ? Math.round((part / total) * 100) : 0; }
function formatDateFa(date, options = {}) { return new Intl.DateTimeFormat('fa-IR-u-ca-persian', options).format(date); }
function getPersianParts(date) {
  const parts = new Intl.DateTimeFormat('en-US-u-ca-persian', { year: 'numeric', month: 'numeric', day: 'numeric' }).formatToParts(date);
  const output = {};
  parts.forEach(part => { if (['year','month','day'].includes(part.type)) output[part.type] = Number(part.value); });
  return output;
}
function getPersianMonthBounds(date) {
  let start = startOfDay(date);
  while (getPersianParts(start).day !== 1) start = new Date(start.getTime() - DAY_MS);
  const current = getPersianParts(start);
  let next = new Date(start.getTime() + 27 * DAY_MS);
  while (true) {
    const parts = getPersianParts(next);
    if (parts.day === 1 && (parts.month !== current.month || parts.year !== current.year)) break;
    next = new Date(next.getTime() + DAY_MS);
  }
  return { start, next, year: current.year, month: current.month };
}
function weeklyDaysForCount(count) {
  const preferred = [6, 1, 3, 5, 0, 2, 4];
  return preferred.slice(0, clamp(Number(count || 1), 1, 7));
}
function getTodayKey() { return dateKey(new Date()); }
function isSameDate(a, b) { return dateKey(a) === dateKey(b); }
function escapeHTML(value = '') { return String(value).replace(/[&<>'"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[ch])); }

function loadData() {
  try {
    const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (!parsed || typeof parsed !== 'object') return seedData(clone(defaultData));
    return migrateData(parsed);
  } catch {
    return seedData(clone(defaultData));
  }
}

function migrateData(raw) {
  const base = clone(defaultData);
  return {
    ...base,
    ...raw,
    settings: { ...base.settings, ...(raw.settings || {}) },
    goals: Array.isArray(raw.goals) ? raw.goals : [],
    completions: raw.completions || {},
    urges: Array.isArray(raw.urges) ? raw.urges : [],
    focusSessions: Array.isArray(raw.focusSessions) ? raw.focusSessions : [],
    reflections: raw.reflections || {}
  };
}

function seedData(base) {
  const today = getTodayKey();
  base.goals = [
    {
      id: uid(), title: '۲۰ دقیقه بدون اینستاگرام بعد از بیداری', type: 'avoid', category: 'digital', difficulty: 2,
      schedule: { type: 'daily' }, reminderTime: '08:00', duration: 20, note: 'روز را بدون ورودی فوری شروع کن.', active: true, archived: false, createdAt: today
    },
    {
      id: uid(), title: '۱۰ دقیقه پیاده‌روی', type: 'build', category: 'health', difficulty: 2,
      schedule: { type: 'daily' }, reminderTime: '18:00', duration: 10, note: 'برای کاهش بی‌قراری و بازیابی تمرکز.', active: true, archived: false, createdAt: today
    },
    {
      id: uid(), title: 'امروز قلیان نکشم', type: 'avoid', category: 'health', difficulty: 4,
      schedule: { type: 'daily' }, reminderTime: '', duration: null, note: 'میل را ثبت کن و ۱۰ دقیقه تصمیم را عقب بینداز.', active: true, archived: false, createdAt: today
    }
  ];
  return base;
}

function saveData() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

function goalPoints(goal) {
  const difficulty = Number(goal.difficulty || 1);
  const base = goal.type === 'avoid' ? 8 : goal.type === 'task' ? 6 : 5;
  return base + difficulty * 3;
}

function completionKey(goalId, dayKey) { return `${goalId}::${dayKey}`; }
function getCompletion(goalId, dayKey) { return data.completions[completionKey(goalId, dayKey)] || null; }
function isCompleted(goalId, dayKey) { return Boolean(getCompletion(goalId, dayKey)?.completed); }

function isGoalScheduledForDate(goal, date) {
  if (!goal.active || goal.archived) return false;
  const created = parseDateKey(goal.createdAt || getTodayKey());
  if (startOfDay(date) < startOfDay(created)) return false;
  const schedule = goal.schedule || { type: 'daily' };
  if (schedule.type === 'daily') return true;
  if (schedule.type === 'weekdays') return (schedule.days || []).map(Number).includes(date.getDay());
  if (schedule.type === 'once') return schedule.date === dateKey(date);
  if (schedule.type === 'weekly') return weeklyDaysForCount(schedule.count).includes(date.getDay());
  return true;
}

function getWeekStart(date) {
  const d = startOfDay(date);
  const day = d.getDay();
  const distanceFromSaturday = (day + 1) % 7;
  d.setDate(d.getDate() - distanceFromSaturday);
  return d;
}

function getScheduledGoals(date) {
  return data.goals.filter(goal => isGoalScheduledForDate(goal, date));
}

function getGoalCompletionsBetween(goalId, start, end) {
  const output = [];
  for (let cursor = startOfDay(start); cursor <= startOfDay(end); cursor = new Date(cursor.getTime() + DAY_MS)) {
    const item = getCompletion(goalId, dateKey(cursor));
    if (item?.completed) output.push(item);
  }
  return output;
}

function toggleCompletion(goalId, dayKey = getTodayKey()) {
  const goal = data.goals.find(item => item.id === goalId);
  if (!goal) return;
  const key = completionKey(goalId, dayKey);
  const existing = data.completions[key];
  if (existing?.completed) {
    data.points = Math.max(0, data.points - Number(existing.points || goalPoints(goal)));
    delete data.completions[key];
    showToast('تیک برداشته شد');
  } else {
    const points = goalPoints(goal);
    data.completions[key] = { completed: true, completedAt: new Date().toISOString(), points };
    data.points += points;
    playSuccessSound();
    showToast(`آفرین! ${toFa(points)} امتیاز گرفتی`);
  }
  saveData();
  renderAll();
}

function archiveGoal(goalId) {
  const goal = data.goals.find(item => item.id === goalId);
  if (!goal) return;
  goal.archived = !goal.archived;
  goal.active = !goal.archived;
  saveData();
  renderAll();
  showToast(goal.archived ? 'هدف به آرشیو رفت' : 'هدف دوباره فعال شد');
}

function deleteGoal(goalId) {
  const goal = data.goals.find(item => item.id === goalId);
  if (!goal || !confirm(`هدف «${goal.title}» حذف شود؟`)) return;
  data.goals = data.goals.filter(item => item.id !== goalId);
  Object.keys(data.completions).forEach(key => { if (key.startsWith(`${goalId}::`)) delete data.completions[key]; });
  saveData();
  renderAll();
  showToast('هدف حذف شد');
}

function getDayStats(date) {
  const key = dateKey(date);
  const scheduled = getScheduledGoals(date);
  const completed = scheduled.filter(goal => isCompleted(goal.id, key));
  return { scheduled, completed, rate: percent(completed.length, scheduled.length) };
}

function calculateSuccessfulDays() {
  if (!data.goals.length) return 0;
  const first = data.goals.map(goal => parseDateKey(goal.createdAt || getTodayKey())).sort((a,b) => a-b)[0];
  let count = 0;
  for (let cursor = first; cursor <= startOfDay(new Date()); cursor = new Date(cursor.getTime() + DAY_MS)) {
    const stats = getDayStats(cursor);
    if (stats.scheduled.length && stats.rate >= 70) count += 1;
  }
  return count;
}

function calculateCurrentStreak() {
  let streak = 0;
  let cursor = startOfDay(new Date());
  const todayStats = getDayStats(cursor);
  if (todayStats.scheduled.length && todayStats.rate < 70) cursor = new Date(cursor.getTime() - DAY_MS);
  for (let i = 0; i < 3650; i += 1) {
    const stats = getDayStats(cursor);
    if (!stats.scheduled.length || stats.rate < 70) break;
    streak += 1;
    cursor = new Date(cursor.getTime() - DAY_MS);
  }
  return streak;
}

function calculateBestStreak(rangeDays = 3650) {
  let best = 0, current = 0;
  const end = startOfDay(new Date());
  const start = new Date(end.getTime() - (rangeDays - 1) * DAY_MS);
  for (let cursor = start; cursor <= end; cursor = new Date(cursor.getTime() + DAY_MS)) {
    const stats = getDayStats(cursor);
    if (stats.scheduled.length && stats.rate >= 70) { current += 1; best = Math.max(best, current); }
    else current = 0;
  }
  return best;
}

function goalStreak(goal) {
  let streak = 0;
  let cursor = startOfDay(new Date());
  if (!isCompleted(goal.id, dateKey(cursor))) cursor = new Date(cursor.getTime() - DAY_MS);
  for (let i = 0; i < 3650; i += 1) {
    if (!isGoalScheduledForDate(goal, cursor)) { cursor = new Date(cursor.getTime() - DAY_MS); continue; }
    if (!isCompleted(goal.id, dateKey(cursor))) break;
    streak += 1;
    cursor = new Date(cursor.getTime() - DAY_MS);
  }
  return streak;
}

function renderAll() {
  renderHeader();
  renderToday();
  renderGoals();
  renderCalendar();
  renderFocusSessions();
  renderInsights();
  renderSettings();
  renderProfile();
  renderUrgeGoalOptions();
}

function renderHeader() {
  el('todayLabel').textContent = formatDateFa(new Date(), { weekday: 'long', day: 'numeric', month: 'long' });
  const titles = { today: 'امروز', goals: 'هدف‌ها', calendar: 'تقویم', focus: 'تمرکز', insights: 'گزارش', settings: 'تنظیمات' };
  el('pageTitle').textContent = titles[activeView] || 'ریست';
  qsa('.bottom-nav button').forEach(button => button.classList.toggle('active', button.dataset.nav === activeView));
  el('fabButton').hidden = !['today', 'goals'].includes(activeView);
}

function renderToday() {
  const today = new Date();
  const key = getTodayKey();
  const { scheduled, completed, rate } = getDayStats(today);
  el('todayProgress').textContent = `${toFa(rate)}٪`;
  el('scoreRing').style.setProperty('--progress', `${rate}%`);
  el('totalPoints').textContent = toFa(data.points);
  el('currentStreak').textContent = `${toFa(calculateCurrentStreak())} روز`;
  el('successfulDays').textContent = `${toFa(calculateSuccessfulDays())} روز`;
  el('todayTaskSummary').textContent = scheduled.length ? `${toFa(completed.length)} از ${toFa(scheduled.length)} مورد انجام شده` : 'هنوز کاری برای امروز نداری.';
  el('heroMessage').textContent = rate === 100 && scheduled.length ? 'امروز را کامل کردی؛ عالی بود.' : rate >= 70 ? 'بخش اصلی روزت را ساختی.' : rate > 0 ? 'همین روند کوچک را ادامه بده.' : 'قدم‌های کوچک، ذهن آرام‌تر.';
  el('heroSubtext').textContent = scheduled.length ? `${toFa(scheduled.length - completed.length)} قدم تا پایان برنامه امروز باقی مانده.` : 'روی کارهای مهم تمرکز کن؛ نه محرک‌های فوری.';

  const list = el('todayTasks');
  list.innerHTML = '';
  scheduled.sort((a,b) => Number(isCompleted(a.id,key)) - Number(isCompleted(b.id,key))).forEach(goal => {
    const done = isCompleted(goal.id, key);
    const card = document.createElement('article');
    card.className = `task-card${done ? ' completed' : ''}`;
    const scheduleLabel = goal.reminderTime ? `یادآوری ${toFa(goal.reminderTime)}` : scheduleText(goal);
    card.innerHTML = `
      <button class="check-button" data-toggle-goal="${goal.id}" aria-label="${done ? 'برداشتن تیک' : 'انجام شد'}">${done ? '✓' : '○'}</button>
      <div><strong class="task-title">${escapeHTML(goal.title)}</strong><div class="task-meta"><span>${typeText(goal.type)}</span><span>${escapeHTML(scheduleLabel)}</span>${goal.duration ? `<span>${toFa(goal.duration)} دقیقه</span>` : ''}</div></div>
      <span class="points-pill">+${toFa(goalPoints(goal))}</span>`;
    list.append(card);
  });
  el('emptyToday').hidden = scheduled.length > 0;
  renderAvoidanceQuickList();
}

function renderAvoidanceQuickList() {
  const goals = data.goals.filter(goal => goal.type === 'avoid' && !goal.archived && goal.active);
  const list = el('avoidanceQuickList');
  list.innerHTML = '';
  if (!goals.length) {
    list.innerHTML = `<div class="avoidance-card"><strong>محرکی ثبت نشده</strong><p>یک هدف از نوع «کاهش محرک» بساز.</p><footer><span class="clean-badge">شروع آگاهانه</span><button class="link-button" data-open-goal-modal>افزودن</button></footer></div>`;
    return;
  }
  goals.forEach(goal => {
    const slipCount = data.urges.filter(item => item.goalId === goal.id && item.outcome === 'slip').length;
    const streak = goalStreak(goal);
    const card = document.createElement('article');
    card.className = 'avoidance-card';
    card.innerHTML = `<div><strong>${escapeHTML(goal.title)}</strong><p>${slipCount ? `${toFa(slipCount)} لغزش ثبت‌شده؛ مسیر ادامه دارد.` : 'هنوز لغزشی ثبت نشده.'}</p></div><footer><span class="clean-badge">${toFa(streak)} روز پیوسته</span><button class="link-button" data-quick-urge="${goal.id}">ثبت میل</button></footer>`;
    list.append(card);
  });
}

function renderGoals() {
  const list = el('goalsList');
  list.innerHTML = '';
  let goals = [...data.goals];
  if (activeGoalFilter === 'build') goals = goals.filter(goal => goal.type !== 'avoid' && !goal.archived);
  if (activeGoalFilter === 'avoid') goals = goals.filter(goal => goal.type === 'avoid' && !goal.archived);
  if (activeGoalFilter === 'done') goals = goals.filter(goal => goal.archived);
  if (activeGoalFilter === 'all') goals = goals.filter(goal => !goal.archived);

  if (!goals.length) {
    list.innerHTML = `<div class="empty-state"><div class="empty-icon">◎</div><h3>موردی در این بخش نیست</h3><p>هدف‌های کوچک‌تر، احتمال تداوم بیشتری دارند.</p></div>`;
    return;
  }

  goals.forEach(goal => {
    const created = parseDateKey(goal.createdAt || getTodayKey());
    let scheduledCount = 0;
    for (let cursor = startOfDay(created); cursor <= startOfDay(new Date()); cursor = new Date(cursor.getTime() + DAY_MS)) {
      if (isGoalScheduledForDate(goal, cursor)) scheduledCount += 1;
    }
    const completions = getGoalCompletionsBetween(goal.id, created, new Date()).length;
    const rate = percent(completions, Math.max(1, scheduledCount));
    const card = document.createElement('article');
    card.className = 'goal-card';
    card.innerHTML = `
      <div class="goal-card-top">
        <div><span class="type-badge ${goal.type}">${typeText(goal.type)}</span><h3>${escapeHTML(goal.title)}</h3><p>${escapeHTML(goal.note || scheduleText(goal))}</p></div>
        <div class="goal-actions"><button data-edit-goal="${goal.id}" title="ویرایش">✎</button><button data-archive-goal="${goal.id}" title="${goal.archived ? 'فعال‌سازی' : 'آرشیو'}">${goal.archived ? '↺' : '□'}</button><button data-delete-goal="${goal.id}" title="حذف">×</button></div>
      </div>
      <div class="goal-progress"><div class="goal-meta-row"><span>${escapeHTML(scheduleText(goal))}</span><span>${toFa(goalStreak(goal))} روز استریک</span><span>${toFa(completions)} بار انجام</span></div><div class="progress-line"><span style="--width:${clamp(rate,0,100)}%"></span></div></div>`;
    list.append(card);
  });
}

function scheduleText(goal) {
  const s = goal.schedule || { type: 'daily' };
  if (s.type === 'daily') return 'هر روز';
  if (s.type === 'weekly') return `${toFa(s.count || 1)} بار در هفته`;
  if (s.type === 'once') return s.date ? formatDateFa(parseDateKey(s.date), { day: 'numeric', month: 'long', year: 'numeric' }) : 'تاریخ مشخص';
  if (s.type === 'weekdays') {
    const labels = {6:'ش',0:'ی',1:'د',2:'س',3:'چ',4:'پ',5:'ج'};
    return (s.days || []).map(day => labels[day]).join('، ') || 'روزهای انتخابی';
  }
  return 'برنامه‌ریزی‌شده';
}

function typeText(type) { return ({ build: 'عادت سازنده', avoid: 'کاهش محرک', task: 'کار مشخص' })[type] || 'هدف'; }

function renderCalendar() {
  const bounds = getPersianMonthBounds(calendarCursor);
  el('calendarMonthTitle').textContent = formatDateFa(bounds.start, { month: 'long', year: 'numeric' });
  const grid = el('calendarGrid');
  grid.innerHTML = '';

  const offset = (bounds.start.getDay() + 1) % 7;
  const gridStart = new Date(bounds.start.getTime() - offset * DAY_MS);
  for (let index = 0; index < 42; index += 1) {
    const date = new Date(gridStart.getTime() + index * DAY_MS);
    const persian = getPersianParts(date);
    const stats = getDayStats(date);
    const key = dateKey(date);
    const button = document.createElement('button');
    button.className = 'calendar-day';
    if (persian.month !== bounds.month || persian.year !== bounds.year) button.classList.add('outside');
    if (isSameDate(date, new Date())) button.classList.add('today');
    if (key === selectedCalendarDate) button.classList.add('selected');
    if (stats.scheduled.length) button.dataset.rate = stats.rate >= 70 ? 'high' : stats.rate >= 30 ? 'mid' : 'low';
    button.dataset.calendarDate = key;
    button.innerHTML = `<span>${toFa(persian.day)}</span>${stats.scheduled.length ? '<i class="day-dot"></i>' : ''}`;
    grid.append(button);
  }
  renderSelectedDayPanel();
}

function renderSelectedDayPanel() {
  const date = parseDateKey(selectedCalendarDate);
  const stats = getDayStats(date);
  const panel = el('selectedDayPanel');
  const items = stats.scheduled.map(goal => `<div class="day-summary-item"><span>${escapeHTML(goal.title)}</span><strong>${isCompleted(goal.id, selectedCalendarDate) ? 'انجام شد' : 'انجام نشد'}</strong></div>`).join('');
  panel.innerHTML = `<div class="day-summary-header"><h3>${formatDateFa(date, { weekday:'long', day:'numeric', month:'long' })}</h3><strong>${toFa(stats.rate)}٪</strong></div>${stats.scheduled.length ? `<div class="day-summary-items">${items}</div>` : '<p class="helper-text">برای این روز هدفی برنامه‌ریزی نشده بود.</p>'}`;
}

function renderFocusSessions() {
  const today = getTodayKey();
  const sessions = data.focusSessions.filter(item => item.date === today).sort((a,b) => b.completedAt.localeCompare(a.completedAt));
  el('focusTodaySummary').textContent = sessions.length ? `${toFa(sessions.length)} جلسه و ${toFa(sessions.reduce((sum,item)=>sum+item.minutes,0))} دقیقه تمرکز` : 'هنوز جلسه‌ای ثبت نشده.';
  const list = el('focusSessionsList');
  list.innerHTML = sessions.length ? sessions.map(session => `<div class="simple-list-item"><div><strong>${escapeHTML(session.task || 'جلسه تمرکز')}</strong><br><small>${formatDateFa(new Date(session.completedAt), { hour:'2-digit', minute:'2-digit' })}</small></div><strong>${toFa(session.minutes)} دقیقه</strong></div>`).join('') : '<div class="empty-state"><p>اولین جلسه تمرکز امروز را شروع کن.</p></div>';
}

function renderInsights() {
  const range = Number(el('insightRange')?.value || 30);
  const end = startOfDay(new Date());
  const start = new Date(end.getTime() - (range - 1) * DAY_MS);
  let scheduled = 0, completed = 0;
  const points = [];
  for (let cursor = start; cursor <= end; cursor = new Date(cursor.getTime() + DAY_MS)) {
    const stats = getDayStats(cursor);
    scheduled += stats.scheduled.length;
    completed += stats.completed.length;
    points.push({ date: new Date(cursor), rate: stats.rate, hasTasks: stats.scheduled.length > 0 });
  }
  const rate = percent(completed, scheduled);
  el('completionRate').textContent = `${toFa(rate)}٪`;
  el('completionCaption').textContent = scheduled ? `${toFa(completed)} از ${toFa(scheduled)} اقدام انجام شده` : 'هنوز داده کافی نیست.';
  el('bestStreak').textContent = `${toFa(calculateBestStreak(range))} روز`;
  const focusMinutes = data.focusSessions.filter(item => parseDateKey(item.date) >= start && parseDateKey(item.date) <= end).reduce((sum,item)=>sum+Number(item.minutes || 0),0);
  el('focusMinutesTotal').textContent = `${toFa(focusMinutes)} دقیقه`;
  const managed = data.urges.filter(item => {
    const d = new Date(item.createdAt); return d >= start && d <= new Date(end.getTime() + DAY_MS - 1) && item.outcome !== 'slip';
  }).length;
  el('managedUrges').textContent = toFa(managed);

  const chart = el('progressChart');
  chart.innerHTML = points.map((point, index) => {
    const showLabel = range <= 7 || index % Math.ceil(range / 8) === 0 || index === points.length - 1;
    return `<div class="chart-column" title="${formatDateFa(point.date,{day:'numeric',month:'long'})}: ${point.rate}%"><span style="--height:${point.hasTasks ? Math.max(4, point.rate) : 2}%"></span><small>${showLabel ? toFa(point.date.getDate()) : ''}</small></div>`;
  }).join('');

  renderSmartInsights(range, rate, focusMinutes, managed);
  renderLatestReflection();
}

function renderSmartInsights(range, rate, focusMinutes, managed) {
  const notes = [];
  const avoidGoals = data.goals.filter(goal => goal.type === 'avoid' && !goal.archived);
  const slipCount = data.urges.filter(item => item.outcome === 'slip').length;
  if (rate >= 80) notes.push(['پیوستگی خوب', `در ${toFa(range)} روز اخیر، نرخ انجام تو بالای ۸۰٪ بوده. برای جلوگیری از فرسودگی، فعلاً هدف‌های جدید زیادی اضافه نکن.`]);
  else if (rate >= 50) notes.push(['مسیر پایدار', 'بیش از نیمی از برنامه را انجام داده‌ای. هدف‌هایی که چند روز پشت‌سرهم جا می‌مانند، احتمالاً باید کوچک‌تر شوند.']);
  else notes.push(['کوچک‌ترش کن', 'یک هدف را انتخاب کن و نسخه دو دقیقه‌ای آن را بساز؛ شروع خیلی کوچک، مقاومت ذهنی را کم می‌کند.']);
  if (avoidGoals.length && managed > slipCount) notes.push(['مدیریت تکانه', 'تعداد میل‌های مدیریت‌شده از لغزش‌ها بیشتر است. ثبت محرک قبل از تصمیم، برای تو مفید بوده است.']);
  if (focusMinutes < 50) notes.push(['تمرکز قابل رشد', 'این هفته یک جلسه ۱۰ دقیقه‌ای در ابتدای روز بگذار؛ کوتاه اما بدون جابه‌جایی بین کارها.']);
  const reflections = Object.values(data.reflections).filter(Boolean);
  if (reflections.length < 3) notes.push(['مرور شبانه', 'سه شب مرور کوتاه ثبت کن تا الگوی محرک‌ها و زمان‌های افت انرژی واضح‌تر شود.']);
  el('smartInsights').innerHTML = notes.slice(0,4).map(([title,text]) => `<div class="insight-note"><b>✦</b><p><strong>${title}</strong><br>${text}</p></div>`).join('');
}

function renderLatestReflection() {
  const keys = Object.keys(data.reflections).sort().reverse();
  const latestKey = keys[0];
  if (!latestKey) {
    el('latestReflection').innerHTML = 'هنوز مرور شبانه‌ای ثبت نشده. امشب فقط یک برد کوچک و یک اولویت فردا را بنویس.';
    return;
  }
  const item = data.reflections[latestKey];
  el('latestReflection').innerHTML = `<strong>${formatDateFa(parseDateKey(latestKey), { day:'numeric', month:'long' })}</strong><br>${item.win ? `برد: ${escapeHTML(item.win)}<br>` : ''}${item.challenge ? `مانع: ${escapeHTML(item.challenge)}<br>` : ''}${item.tomorrow ? `فردا: ${escapeHTML(item.tomorrow)}` : ''}`;
}

function renderSettings() {
  el('dayStartTime').value = data.settings.dayStartTime;
  el('nightReminderTime').value = data.settings.nightReminderTime;
  el('gentleModeToggle').checked = data.settings.gentleMode;
  el('levelToggle').checked = data.settings.showLevel;
  el('soundToggle').checked = data.settings.sound;
}

function renderProfile() {
  const level = Math.floor(data.points / 250) + 1;
  const levelProgress = data.points % 250;
  const activeGoals = data.goals.filter(goal => !goal.archived).length;
  el('profileContent').innerHTML = `<div class="profile-level"><span>سطح فعلی</span><strong>سطح ${toFa(level)}</strong><p>${toFa(levelProgress)} از ${toFa(250)} امتیاز تا سطح بعد</p><div class="progress-line" style="margin-top:12px"><span style="--width:${percent(levelProgress,250)}%"></span></div></div><div class="simple-list-item"><span>هدف فعال</span><strong>${toFa(activeGoals)}</strong></div><div class="simple-list-item"><span>روز موفق</span><strong>${toFa(calculateSuccessfulDays())}</strong></div><div class="simple-list-item"><span>بهترین استریک</span><strong>${toFa(calculateBestStreak())} روز</strong></div>`;
}

function renderUrgeGoalOptions() {
  const options = data.goals.filter(goal => goal.type === 'avoid' && !goal.archived);
  el('urgeGoalSelect').innerHTML = options.length ? options.map(goal => `<option value="${goal.id}">${escapeHTML(goal.title)}</option>`).join('') : '<option value="general">محرک عمومی</option>';
}

function navigate(view) {
  activeView = view;
  qsa('.view').forEach(section => section.classList.toggle('active', section.dataset.view === view));
  renderHeader();
  window.scrollTo({ top: 0, behavior: 'smooth' });
  el('mainContent').focus({ preventScroll: true });
}

function openModal(id) {
  const modal = el(id);
  if (!modal) return;
  modal.hidden = false;
  document.body.style.overflow = 'hidden';
}
function closeModal(id) {
  const modal = el(id);
  if (!modal) return;
  modal.hidden = true;
  if (!qsa('.modal-backdrop:not([hidden])').length) document.body.style.overflow = '';
}

function resetGoalForm() {
  el('goalForm').reset();
  el('goalId').value = '';
  el('goalDifficulty').value = '2';
  el('goalScheduleType').value = 'daily';
  el('goalModalTitle').textContent = 'یک قدم کوچک تعریف کن';
  updateScheduleFields();
}

function editGoal(goalId) {
  const goal = data.goals.find(item => item.id === goalId);
  if (!goal) return;
  resetGoalForm();
  el('goalId').value = goal.id;
  el('goalTitle').value = goal.title;
  el('goalType').value = goal.type;
  el('goalDifficulty').value = goal.difficulty;
  el('goalCategory').value = goal.category;
  el('goalScheduleType').value = goal.schedule?.type || 'daily';
  el('goalWeeklyCount').value = goal.schedule?.count || 3;
  el('goalSpecificDate').value = goal.schedule?.date || '';
  el('goalReminderTime').value = goal.reminderTime || '';
  el('goalDuration').value = goal.duration || '';
  el('goalNote').value = goal.note || '';
  updateScheduleFields();
  qsa('#weekdayPicker input').forEach(input => { input.checked = (goal.schedule?.days || []).map(Number).includes(Number(input.value)); });
  el('goalModalTitle').textContent = 'ویرایش هدف';
  openModal('goalModal');
}

function updateScheduleFields() {
  const type = el('goalScheduleType').value;
  el('weekdayPicker').hidden = type !== 'weekdays';
  el('weeklyCountField').hidden = type !== 'weekly';
  el('specificDateField').hidden = type !== 'once';
  if (type === 'once' && !el('goalSpecificDate').value) el('goalSpecificDate').value = getTodayKey();
}

function submitGoal(event) {
  event.preventDefault();
  const id = el('goalId').value;
  const scheduleType = el('goalScheduleType').value;
  const schedule = { type: scheduleType };
  if (scheduleType === 'weekdays') schedule.days = qsa('#weekdayPicker input:checked').map(input => Number(input.value));
  if (scheduleType === 'weekly') schedule.count = Number(el('goalWeeklyCount').value || 1);
  if (scheduleType === 'once') schedule.date = el('goalSpecificDate').value;
  if (scheduleType === 'weekdays' && !schedule.days.length) return showToast('حداقل یک روز هفته انتخاب کن');
  if (scheduleType === 'once' && !schedule.date) return showToast('تاریخ انجام را انتخاب کن');

  const payload = {
    title: el('goalTitle').value.trim(),
    type: el('goalType').value,
    difficulty: Number(el('goalDifficulty').value),
    category: el('goalCategory').value,
    schedule,
    reminderTime: el('goalReminderTime').value,
    duration: el('goalDuration').value ? Number(el('goalDuration').value) : null,
    note: el('goalNote').value.trim(),
    active: true,
    archived: false
  };
  if (!payload.title) return;
  if (id) Object.assign(data.goals.find(goal => goal.id === id), payload);
  else data.goals.unshift({ id: uid(), ...payload, createdAt: getTodayKey() });
  saveData();
  closeModal('goalModal');
  renderAll();
  showToast(id ? 'هدف ویرایش شد' : 'هدف جدید ساخته شد');
}

function submitUrge(event) {
  event.preventDefault();
  const outcome = el('urgeOutcome').value;
  data.urges.push({
    id: uid(), goalId: el('urgeGoalSelect').value, intensity: Number(el('urgeIntensity').value), trigger: el('urgeTrigger').value.trim(), outcome, createdAt: new Date().toISOString()
  });
  if (outcome === 'managed') data.points += 5;
  if (outcome === 'delayed') data.points += 3;
  saveData();
  closeModal('urgeModal');
  el('urgeForm').reset();
  el('urgeIntensity').value = '5';
  el('urgeIntensityValue').textContent = '۵';
  renderAll();
  showToast(outcome === 'slip' ? 'ثبت شد؛ بدون سرزنش ادامه بده' : 'میل را آگاهانه مدیریت کردی');
}

function submitReflection(event) {
  event.preventDefault();
  const mood = Number(new FormData(event.currentTarget).get('mood') || 3);
  data.reflections[getTodayKey()] = { mood, win: el('reflectionWin').value.trim(), challenge: el('reflectionChallenge').value.trim(), tomorrow: el('reflectionTomorrow').value.trim(), updatedAt: new Date().toISOString() };
  data.points += 4;
  saveData();
  closeModal('reflectionModal');
  renderAll();
  showToast('مرور امروز ذخیره شد');
}

function updateFocusDisplay() {
  const minutes = Math.floor(focusState.remaining / 60);
  const seconds = focusState.remaining % 60;
  const text = `${toFa(pad(minutes))}:${toFa(pad(seconds))}`;
  el('focusTimer').textContent = text;
  el('focusMiniTime').textContent = text;
  el('focusStartBtn').textContent = focusState.running ? 'توقف' : focusState.remaining < focusState.total ? 'ادامه' : 'شروع';
}

function toggleFocusTimer() {
  if (focusState.running) {
    clearInterval(focusState.interval);
    focusState.running = false;
    updateFocusDisplay();
    return;
  }
  focusState.running = true;
  focusState.startedAt = focusState.startedAt || new Date().toISOString();
  focusState.interval = setInterval(() => {
    focusState.remaining -= 1;
    updateFocusDisplay();
    if (focusState.remaining <= 0) completeFocusSession();
  }, 1000);
  updateFocusDisplay();
}

function completeFocusSession() {
  clearInterval(focusState.interval);
  focusState.running = false;
  const minutes = Math.round(focusState.total / 60);
  data.focusSessions.push({ id: uid(), date: getTodayKey(), minutes, task: el('focusTaskInput').value.trim(), startedAt: focusState.startedAt, completedAt: new Date().toISOString() });
  data.points += Math.max(5, Math.round(minutes / 2));
  saveData();
  notify('جلسه تمرکز تمام شد', 'آفرین؛ چند نفس عمیق بکش و نتیجه را ثبت کن.');
  showToast(`جلسه ${toFa(minutes)} دقیقه‌ای کامل شد`);
  resetFocusTimer();
  renderAll();
}

function resetFocusTimer() {
  clearInterval(focusState.interval);
  const preset = Number(qsa('.timer-presets button.active')[0]?.dataset.minutes || 25);
  focusState = { total: preset * 60, remaining: preset * 60, running: false, interval: null, startedAt: null };
  updateFocusDisplay();
}

function chooseFocusPreset(minutes) {
  qsa('.timer-presets button').forEach(button => button.classList.toggle('active', Number(button.dataset.minutes) === minutes));
  clearInterval(focusState.interval);
  focusState = { total: minutes * 60, remaining: minutes * 60, running: false, interval: null, startedAt: null };
  updateFocusDisplay();
}

function updateUrgeTimerDisplay() {
  const minutes = Math.floor(urgeState.remaining / 60);
  const seconds = urgeState.remaining % 60;
  el('urgeTimer').textContent = `${toFa(pad(minutes))}:${toFa(pad(seconds))}`;
  el('urgeTimerBtn').textContent = urgeState.running ? 'توقف' : urgeState.remaining < urgeState.total ? 'ادامه' : 'شروع موج‌سواری';
}

function toggleUrgeTimer() {
  if (urgeState.running) {
    clearInterval(urgeState.interval); urgeState.running = false; updateUrgeTimerDisplay(); return;
  }
  urgeState.running = true;
  el('urgeTimerHint').textContent = 'میل مثل موج بالا می‌آید و پایین می‌رود؛ فقط مشاهده‌اش کن.';
  urgeState.interval = setInterval(() => {
    urgeState.remaining -= 1;
    updateUrgeTimerDisplay();
    if (urgeState.remaining <= 0) {
      clearInterval(urgeState.interval);
      urgeState = { total: 600, remaining: 600, running: false, interval: null };
      el('urgeTimerHint').textContent = 'ده دقیقه گذشت؛ حالا دوباره آگاهانه تصمیم بگیر.';
      notify('۱۰ دقیقه گذشت', 'میل اولیه احتمالاً ضعیف‌تر شده؛ حالا آگاهانه تصمیم بگیر.');
      showToast('موج ۱۰ دقیقه‌ای کامل شد');
      updateUrgeTimerDisplay();
      openModal('urgeModal');
    }
  }, 1000);
  updateUrgeTimerDisplay();
}

async function requestNotifications() {
  if (!('Notification' in window)) return showToast('مرورگر از اعلان پشتیبانی نمی‌کند');
  const permission = await Notification.requestPermission();
  if (permission === 'granted') {
    showToast('اعلان‌ها فعال شد');
    notify('یادآوری‌های ریست فعال شد', 'وقتی برنامه باز باشد، یادآوری‌ها اجرا می‌شوند.');
  } else showToast('اجازه اعلان داده نشد');
}

function notify(title, body) {
  if (!('Notification' in window) || Notification.permission !== 'granted') return;
  if (navigator.serviceWorker?.controller) navigator.serviceWorker.ready.then(reg => reg.showNotification(title, { body, icon: 'icons/icon.svg', badge: 'icons/icon.svg', tag: 'dopamine-reset' }));
  else new Notification(title, { body, icon: 'icons/icon.svg' });
}

function checkInAppReminders() {
  const now = new Date();
  const current = `${pad(now.getHours())}:${pad(now.getMinutes())}`;
  const key = getTodayKey();
  getScheduledGoals(now).forEach(goal => {
    if (!goal.reminderTime || isCompleted(goal.id, key)) return;
    const reminderKey = `reminded::${goal.id}::${key}::${goal.reminderTime}`;
    if (current === goal.reminderTime && !sessionStorage.getItem(reminderKey)) {
      sessionStorage.setItem(reminderKey, '1');
      notify('یادآوری هدف', goal.title);
      showToast(`یادآوری: ${goal.title}`);
    }
  });
  if (current === data.settings.nightReminderTime && !sessionStorage.getItem(`night::${key}`)) {
    sessionStorage.setItem(`night::${key}`, '1');
    notify('مرور شبانه', 'یک دقیقه برای ثبت برد امروز و اولویت فردا.');
  }
}

function exportData() {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `dopamine-reset-backup-${getTodayKey()}.json`; a.click();
  URL.revokeObjectURL(url);
  showToast('فایل پشتیبان ساخته شد');
}

function importData(file) {
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const parsed = JSON.parse(reader.result);
      if (!parsed || !Array.isArray(parsed.goals)) throw new Error('invalid');
      data = migrateData(parsed);
      saveData();
      renderAll();
      showToast('پشتیبان بازیابی شد');
    } catch { alert('فایل پشتیبان معتبر نیست.'); }
  };
  reader.readAsText(file);
}

function resetData() {
  if (!confirm('همه هدف‌ها، امتیازها و تاریخچه پاک شوند؟')) return;
  data = seedData(clone(defaultData));
  saveData();
  renderAll();
  showToast('برنامه به حالت اولیه برگشت');
}

function playSuccessSound() {
  if (!data.settings.sound) return;
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = ctx.createOscillator();
    const gain = ctx.createGain();
    oscillator.connect(gain); gain.connect(ctx.destination);
    oscillator.frequency.setValueAtTime(520, ctx.currentTime);
    oscillator.frequency.exponentialRampToValueAtTime(780, ctx.currentTime + .12);
    gain.gain.setValueAtTime(.06, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(.001, ctx.currentTime + .22);
    oscillator.start(); oscillator.stop(ctx.currentTime + .22);
  } catch { /* ignore */ }
}

function showToast(message) {
  const toast = el('toast');
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2400);
}

function bindEvents() {
  document.addEventListener('click', (event) => {
    const target = event.target.closest('button, [data-open-goal-modal], [data-close-modal], [data-nav-target], [data-toggle-goal], [data-edit-goal], [data-archive-goal], [data-delete-goal], [data-calendar-date], [data-quick-urge]');
    if (!target) return;
    if (target.dataset.nav) navigate(target.dataset.nav);
    if (target.dataset.navTarget) navigate(target.dataset.navTarget);
    if (target.matches('[data-open-goal-modal]')) { resetGoalForm(); openModal('goalModal'); }
    if (target.dataset.closeModal) closeModal(target.dataset.closeModal);
    if (target.dataset.toggleGoal) toggleCompletion(target.dataset.toggleGoal);
    if (target.dataset.editGoal) editGoal(target.dataset.editGoal);
    if (target.dataset.archiveGoal) archiveGoal(target.dataset.archiveGoal);
    if (target.dataset.deleteGoal) deleteGoal(target.dataset.deleteGoal);
    if (target.dataset.calendarDate) { selectedCalendarDate = target.dataset.calendarDate; renderCalendar(); }
    if (target.dataset.quickUrge) { el('urgeGoalSelect').value = target.dataset.quickUrge; openModal('urgeModal'); }
  });

  qsa('.modal-backdrop').forEach(backdrop => backdrop.addEventListener('click', event => { if (event.target === backdrop) closeModal(backdrop.id); }));
  el('goalForm').addEventListener('submit', submitGoal);
  el('urgeForm').addEventListener('submit', submitUrge);
  el('reflectionForm').addEventListener('submit', submitReflection);
  el('goalScheduleType').addEventListener('change', updateScheduleFields);
  el('urgeIntensity').addEventListener('input', event => { el('urgeIntensityValue').textContent = toFa(event.target.value); });
  el('openUrgeModal').addEventListener('click', () => openModal('urgeModal'));
  el('openReflectionModal').addEventListener('click', () => openModal('reflectionModal'));
  el('profileBtn').addEventListener('click', () => openModal('profileModal'));
  el('fabButton').addEventListener('click', () => { resetGoalForm(); openModal('goalModal'); });

  qsa('[data-goal-filter]').forEach(button => button.addEventListener('click', () => {
    activeGoalFilter = button.dataset.goalFilter;
    qsa('[data-goal-filter]').forEach(item => item.classList.toggle('active', item === button));
    renderGoals();
  }));

  el('prevMonthBtn').addEventListener('click', () => { const bounds = getPersianMonthBounds(calendarCursor); calendarCursor = new Date(bounds.start.getTime() - DAY_MS); renderCalendar(); });
  el('nextMonthBtn').addEventListener('click', () => { const bounds = getPersianMonthBounds(calendarCursor); calendarCursor = new Date(bounds.next); renderCalendar(); });
  el('calendarTodayBtn').addEventListener('click', () => { calendarCursor = new Date(); selectedCalendarDate = getTodayKey(); renderCalendar(); });

  qsa('.timer-presets button').forEach(button => button.addEventListener('click', () => chooseFocusPreset(Number(button.dataset.minutes))));
  el('focusStartBtn').addEventListener('click', toggleFocusTimer);
  el('focusResetBtn').addEventListener('click', resetFocusTimer);
  el('urgeTimerBtn').addEventListener('click', toggleUrgeTimer);
  el('notificationBtn').addEventListener('click', requestNotifications);
  el('insightRange').addEventListener('change', renderInsights);

  ['dayStartTime','nightReminderTime'].forEach(id => el(id).addEventListener('change', event => { data.settings[id] = event.target.value; saveData(); showToast('تنظیمات ذخیره شد'); }));
  el('gentleModeToggle').addEventListener('change', event => { data.settings.gentleMode = event.target.checked; saveData(); });
  el('levelToggle').addEventListener('change', event => { data.settings.showLevel = event.target.checked; saveData(); });
  el('soundToggle').addEventListener('change', event => { data.settings.sound = event.target.checked; saveData(); });
  el('exportDataBtn').addEventListener('click', exportData);
  el('importDataInput').addEventListener('change', event => { if (event.target.files[0]) importData(event.target.files[0]); event.target.value = ''; });
  el('resetDataBtn').addEventListener('click', resetData);

  window.addEventListener('beforeinstallprompt', event => { event.preventDefault(); deferredInstallPrompt = event; el('installBtn').hidden = false; });
  el('installBtn').addEventListener('click', async () => {
    if (!deferredInstallPrompt) return;
    deferredInstallPrompt.prompt();
    await deferredInstallPrompt.userChoice;
    deferredInstallPrompt = null;
    el('installBtn').hidden = true;
  });
  window.addEventListener('appinstalled', () => showToast('برنامه نصب شد'));
}

function registerServiceWorker() {
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(() => {});
}

function initialize() {
  bindEvents();
  renderAll();
  updateFocusDisplay();
  updateUrgeTimerDisplay();
  registerServiceWorker();
  checkInAppReminders();
  setInterval(checkInAppReminders, 30000);
}

document.addEventListener('DOMContentLoaded', initialize);
